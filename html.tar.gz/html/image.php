<?php
   $file = $_GET['file'];
   if(isset($file))
   {
       include("$file");
   }
   else
   {
       include("image_of_the_year.2021.html");
   }
?>
